package com.ray.studylock

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("studylock", MODE_PRIVATE) }
    private val apps = listOf("Instagram" to "com.instagram.android", "YouTube" to "com.google.android.youtube")
    private var selected = mutableSetOf<String>()
    private var minutes = 45
    private var subject = "Mathematics"
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        selected = prefs.getStringSet("blocked", setOf("com.instagram.android","com.google.android.youtube"))!!.toMutableSet()
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(28,32,28,24); setBackgroundColor(Color.rgb(12,18,32)) }
        fun label(text:String,size:Float=18f):TextView = TextView(this).apply { this.text=text; textSize=size; setTextColor(Color.WHITE); setPadding(0,12,0,12) }
        root.addView(label("STUDYLOCK  •  FOCUS MODE",22f))
        root.addView(label("Study with intention. Test what you learned.",14f))
        root.addView(label("1. Choose subject"))
        val subjects = listOf("Mathematics","Science","Social Science","English","Assamese","Computer Science","Other")
        val sp = Spinner(this)
        sp.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,subjects)
        root.addView(sp); sp.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(p:AdapterView<*>?) {}
            override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){subject=subjects[pos]}
        }
        root.addView(label("2. Study duration"))
        val times= listOf("25 minutes","45 minutes","60 minutes","90 minutes")
        val ts=Spinner(this); ts.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,times); root.addView(ts)
        ts.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(p:AdapterView<*>?) {}
            override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){minutes=listOf(25,45,60,90)[pos]}
        }
        root.addView(label("3. Apps to block"))
        apps.forEach { (name,pkg) -> root.addView(CheckBox(this).apply {
            text=name; textSize=17f; setTextColor(Color.WHITE); buttonTintList=android.content.res.ColorStateList.valueOf(Color.rgb(90,180,255))
            isChecked=selected.contains(pkg); setOnCheckedChangeListener { _,checked -> if(checked) selected.add(pkg) else selected.remove(pkg) }
        }) }
        status=label("Status: Ready")
        root.addView(status)
        val start=Button(this).apply{text="START STUDY"; textSize=18f}
        root.addView(start)
        start.setOnClickListener {
            if(selected.isEmpty()){Toast.makeText(this,"Select at least one app to block",Toast.LENGTH_SHORT).show();return@setOnClickListener}
            prefs.edit().putStringSet("blocked",selected).putString("subject",subject).putInt("minutes",minutes)
                .putLong("endAt",System.currentTimeMillis()+minutes*60_000L).putBoolean("active",true).apply()
            if(!isAccessibilityEnabled()){startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));Toast.makeText(this,"Enable StudyLock accessibility service, then return and start again.",Toast.LENGTH_LONG).show()}
            else {startService(Intent(this,BlockerService::class.java)); showTestInfo()}
            status.text="Session: $subject • $minutes min"
        }
        val stop=Button(this).apply{text="END SESSION (TEST FIRST)"}
        root.addView(stop); stop.setOnClickListener { showTestInfo() }
        root.addView(label("Daily goals • streaks • session history are planned next.",12f))
        setContentView(ScrollView(this).apply{addView(root)})
    }
    private fun isAccessibilityEnabled():Boolean {
        val expected="$packageName/${BlockerService::class.java.name}"
        return Settings.Secure.getString(contentResolver,Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)?.contains(expected)==true
    }
    private fun showTestInfo(){
        val s=prefs.getString("subject",subject) ?: subject
        AlertDialog.Builder(this).setTitle("Quick study test")
            .setMessage("Session subject: $s\n\nBefore unlocking distractions, answer 3 questions from your notes (or ask a teacher/ChatGPT to quiz you).\n\nThis starter shows the test prompt; quiz scoring and automatic unlock-after-test are the next feature.")
            .setPositiveButton("Start mini-test"){_,_->startActivity(Intent(this,QuizActivity::class.java))}
            .setNegativeButton("Not now",null).show()
    }
}
