package com.ray.studylock

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.content.Intent
import android.view.Gravity
import android.widget.*
import android.graphics.Color

class BlockScreenActivity:Activity(){
    private val h=Handler(Looper.getMainLooper())
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        val p=getSharedPreferences("studylock",MODE_PRIVATE)
        val layout=LinearLayout(this).apply{orientation=1;gravity=Gravity.CENTER;setPadding(30,30,30,30);setBackgroundColor(Color.rgb(12,18,32))}
        layout.addView(TextView(this).apply{text="📚 STUDY IN PROGRESS";textSize=25f;setTextColor(Color.WHITE);gravity=Gravity.CENTER})
        layout.addView(TextView(this).apply{text="This app is paused until your session ends.";textSize=17f;setTextColor(Color.LTGRAY);gravity=Gravity.CENTER;setPadding(0,25,0,25)})
        val timer=TextView(this).apply{textSize=30f;setTextColor(Color.rgb(90,180,255));gravity=Gravity.CENTER}
        layout.addView(timer)
        layout.addView(Button(this).apply{text="Back to studying";setOnClickListener{finish()}})
        layout.addView(Button(this).apply{text="Open study test";setOnClickListener{startActivity(Intent(this@BlockScreenActivity,QuizActivity::class.java))}})
        setContentView(layout)
        val tick=object:Runnable{override fun run(){
            val left=(p.getLong("endAt",0)-System.currentTimeMillis()).coerceAtLeast(0)/1000
            timer.text=String.format("%02d:%02d:%02d",left/3600,(left%3600)/60,left%60)
            if(left==0L){p.edit().putBoolean("active",false).apply();finish()}else h.postDelayed(this,1000)
        }};h.post(tick)
    }
}
