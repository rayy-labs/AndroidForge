package com.ray.studylock

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.widget.*
import android.view.Gravity
import android.graphics.Color

class QuizActivity:Activity(){
 override fun onCreate(savedInstanceState:Bundle?){
  super.onCreate(savedInstanceState)
  val p=getSharedPreferences("studylock",MODE_PRIVATE);val subject=p.getString("subject","your subject")?: "your subject"
  val box=LinearLayout(this).apply{orientation=1;setPadding(28,30,28,30);setBackgroundColor(Color.rgb(12,18,32))}
  box.addView(TextView(this).apply{text="MINI TEST • $subject";textSize=23f;setTextColor(Color.WHITE)})
  box.addView(TextView(this).apply{text="Write answers in your notebook. Create 3 questions from today's lesson:";textSize=17f;setTextColor(Color.LTGRAY);setPadding(0,20,0,15)})
  listOf("1. Explain the main concept in your own words.","2. Write two important facts/formulas.","3. Solve one example or give one application.").forEach{box.addView(TextView(this).apply{text=it;textSize=18f;setTextColor(Color.WHITE);setPadding(0,15,0,15)})}
  box.addView(EditText(this).apply{hint="What did you learn? (optional reflection)";minLines=3;gravity=Gravity.TOP})
  box.addView(Button(this).apply{text="I completed my test • Unlock";setOnClickListener{
   AlertDialog.Builder(this@QuizActivity).setTitle("Test completed?")
    .setMessage("Mark the mini-test complete and end this focus session?")
    .setPositiveButton("Yes, finish session"){_,_->p.edit().putBoolean("active",false).apply();finish();finishAffinity()}
    .setNegativeButton("Keep studying",null).show()
  }})
  setContentView(ScrollView(this).apply{addView(box)})
 }
}
