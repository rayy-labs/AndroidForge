package com.ray.studylock

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.content.Intent
import android.os.Handler
import android.os.Looper

class BlockerService: AccessibilityService() {
    private val handler=Handler(Looper.getMainLooper())
    private var lastPackage=""
    override fun onAccessibilityEvent(event:AccessibilityEvent?) {
        if(event?.eventType!=AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED)return
        val pkg=event.packageName?.toString() ?: return
        if(pkg==packageName)return
        val p=getSharedPreferences("studylock",MODE_PRIVATE)
        if(!p.getBoolean("active",false))return
        val end=p.getLong("endAt",0L)
        if(System.currentTimeMillis()>=end){p.edit().putBoolean("active",false).apply();return}
        val blocked=p.getStringSet("blocked",emptySet()) ?: emptySet()
        if(pkg in blocked && pkg!=lastPackage){
            lastPackage=pkg
            handler.post {
                val i=Intent(this,BlockScreenActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                i.putExtra("app",pkg); startActivity(i)
            }
        }
    }
    override fun onInterrupt(){}
}
