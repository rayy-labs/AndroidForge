# StudyLock Android starter
Features in this prototype:
- Subject selector, 25/45/60/90 minute focus sessions
- Instagram + YouTube app selection
- Accessibility service detects selected apps and opens a blocking screen
- Session countdown and mini-test/reflection screen
- Manual test completion unlock action

## Build
1. Install Android Studio (Ladybug or newer).
2. Open this folder as a project.
3. Let Gradle sync; use JDK 17.
4. Build > Build APK(s).
5. Install APK on your Android phone.
6. Open Android Settings > Accessibility > StudyLock and enable the service.

## Important limitations
This is a starter prototype, not a hardened blocker. Android Accessibility behavior and app launch restrictions vary by OS/device. Users can disable the accessibility permission or force-stop the app; no ordinary app can guarantee an unbreakable lock. Test on your device before relying on it. It does not yet generate subject-specific scored questions; the mini-test is a guided self-test. Next improvements: question bank/AI quiz, scoring, session history, streaks, scheduled sessions, and safer emergency exit.
